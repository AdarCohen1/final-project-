MONGO_URI = "mongodb+srv://adarcohen1:adar123456@mathstarzdb.bs1de.mongodb.net/?retryWrites=true&w=majority"
